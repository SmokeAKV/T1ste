## 6.2.1 (2023-06-07)


### Bug Fixes

* updated proto/version to v2.2323.4 ([#96](https://github.com/WhiskeySockets/Baileys/issues/96)) ([63575e9](https://github.com/WhiskeySockets/Baileys/commit/63575e9b85520bd7621bd16ac0508cdd523a3a43))



